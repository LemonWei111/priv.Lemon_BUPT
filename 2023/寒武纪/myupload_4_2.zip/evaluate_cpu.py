from torchvision.models import vgg19
from torch import nn
from zipfile import ZipFile
from torch.utils.data import Dataset, DataLoader
from torchvision.utils import save_image
import torch
import cv2
import numpy
import time
from PIL import Image

class COCODataSet(Dataset):

    def __init__(self):
        super(COCODataSet, self).__init__()
        self.zip_files = ZipFile('./data/train2014_small.zip')
        self.data_set = []
        for file_name in self.zip_files.namelist():
            if file_name.endswith('.jpg'):
                self.data_set.append(file_name)

    def __len__(self):
        return len(self.data_set)

    def __getitem__(self, item):
        file_path = self.data_set[item]
        image = self.zip_files.read(file_path)
        image = numpy.asarray(bytearray(image), dtype='uint8')
        # TODO: 使用cv2.imdecode()函数从指定的内存缓存中读取数据，并把数据转换(解码)成彩色图像格式。
        decoded_image = cv2.imdecode(image, cv2.IMREAD_COLOR)
        # TODO: 使用cv2.resize()将图像缩放为512*512大小，其中所采用的插值方式为：区域插值
        # 指定目标大小为512x512
        target_size = (512, 512)
        # 使用 cv2.resize 将图像缩放到指定大小，插值方法为区域插值
        resized_image = cv2.resize(decoded_image, target_size, interpolation=cv2.INTER_AREA)
        # TODO: 使用cv2.cvtColor将图片从BGR格式转换成RGB格式
        rgb_image = cv2.cvtColor(resized_image, cv2.COLOR_BGR2RGB)
        # TODO: 将image从numpy形式转换为torch.float32,并将其归一化为[0,1]
        # 转换为 PyTorch 的 Tensor，类型为 torch.float32
        torch_image = torch.from_numpy(rgb_image).float()
        # 归一化到 [0, 1] 范围
        normalized_image = torch_image / 255.0
        # TODO: 用permute函数将tensor从HxWxC转换为CxHxW
        image = normalized_image.permute(2, 0, 1)
        return image

class ResBlock(nn.Module):

    def __init__(self, c):
        super(ResBlock, self).__init__()
        self.layer = nn.Sequential(
            
            #.0TODO: 进行卷积，卷积核为3*1*1
            nn.Conv2d(c, c, kernel_size=(3, 3), stride=1, padding=1, bias=False),
            #.1TODO: 执行实例归一化
            nn.InstanceNorm2d(num_features=c),  # 输入通道数为3
            #.2TODO: 执行ReLU
            nn.ReLU(inplace=True),
            #.3TODO: 进行卷积，卷积核为3*1*1
            nn.Conv2d(c, c, kernel_size=(3, 3), stride=1, padding=1, bias=False),
            #.4TODO: 执行实例归一化
            nn.InstanceNorm2d(num_features=c)  # 输入通道数为3
        )
        
    def forward(self, x):
        #TODO: 返回残差运算的结果
        # 残差运算
        out = 0
        out += self.layer(x)
        # 应用激活函数
        #out = F.relu(out)
        return out


class TransNet(nn.Module):

    def __init__(self):
        super(TransNet, self).__init__()
        c = 32  # 输入通道数

        self.layer = nn.Sequential(
            
            ###################下采样层################
            #0 TODO：构建图像转换网络，第一层卷积
            nn.Conv2d(3, c, kernel_size=(9, 9), stride=2, padding=1, bias=False),
            #1 TODO：实例归一化
            nn.InstanceNorm2d(num_features=c),
            #2 TODO：创建激活函数ReLU
            nn.ReLU(inplace=True),
            #3 TODO：第二层卷积
            nn.Conv2d(c, c * 2, kernel_size=(3, 3), stride=2, padding=1, bias=False),
            #4 TODO：实例归一化
            nn.InstanceNorm2d(num_features=c * 2),
            #5 TODO：创建激活函数ReLU
            nn.ReLU(inplace=True),
            #6 TODO：第三层卷积
            nn.Conv2d(c * 2, c * 4, kernel_size=(3, 3), stride=2, padding=1, bias=False),
            #7 TODO：实例归一化
            nn.InstanceNorm2d(num_features=c * 4),
            #8 TODO：创建激活函数ReLU
            nn.ReLU(inplace=True),

            ##################残差层##################
            #9
            ResBlock(c * 4),
            #10
            ResBlock(c * 4),
            #11
            ResBlock(c * 4),
            #12
            ResBlock(c * 4),
            #13
            ResBlock(c * 4),
            ################上采样层##################
            #14TODO: 使用torch.nn.Upsample对特征图进行上采样
            nn.Upsample(scale_factor=2, mode='nearest'),
            #15TODO: 执行卷积操作
            nn.Conv2d(c * 4, c * 2, kernel_size=(3, 3), stride=1, padding=1, bias=False),
            #16TODO: 实例归一化
            nn.InstanceNorm2d(num_features=c * 2),
            #17TODO: 执行ReLU操作
            nn.ReLU(inplace=True),

            #18TODO: 使用torch.nn.Upsample对特征图进行上采样
            nn.Upsample(scale_factor=2, mode='nearest'),
            #19TODO: 执行卷积操作
            nn.Conv2d(c * 2, c, kernel_size=(3, 3), stride=1, padding=1, bias=False),
            #20TODO: 实例归一化
            nn.InstanceNorm2d(num_features=c),
            #21TODO: 执行ReLU操作
            nn.ReLU(inplace=True),
            
            ###############输出层#####################
            #22TODO: 执行卷积操作,使用偏置[3]
            nn.Conv2d(c, 3, kernel_size=(9, 9), stride=1, padding=1),
            #23TODO： sigmoid激活函数
            nn.Sigmoid()
        )

    def forward(self, x):
        return self.layer(x)
    

Module_PATH = 'models/fst.pth'
if __name__ == '__main__':
    # TODO: 使用cpu生成图像转换网络模型并保存在g_net中
    g_net = TransNet()
    '''
    print("g_net:\n",g_net)
    checkpoint = torch.load(Module_PATH)#, map_location=torch.device('cpu'))
    print("pth:")
    for key, value in checkpoint.items():
        print(key,value.size(),sep="  ")
    '''
    # TODO:从/models文件夹下加载网络参数到g_net中
    g_net.load_state_dict(torch.load(Module_PATH))
    print("g_net build  PASS!\n")
    data_set = COCODataSet()
    print("load COCODataSet PASS!\n")

    batch_size = 1
    data_group = DataLoader(data_set,batch_size,True,drop_last=True)

    for i, image in enumerate(data_group):
        image_c = image.cpu()
        #print(image_c.shape)
        start = time.time()
        # TODO: 计算 g_net,得到image_g
        image_g = g_net(image_c)
        end = time.time()
        delta_time = end - start
        print("Inference (CPU) processing time: %s" % delta_time)
        #TODO: 利用save_image函数将tensor形式的生成图像image_g以及输入图像image_c以jpg格式左右拼接的形式保存在/out/cpu/文件夹下
        # 确保图像的通道维度是第二个维度
        image_g = image_g.cpu().clone()
        image_g = image_g.squeeze(0)
        image_g = image_g.permute(1, 2, 0)
        image_c = image_c.cpu().clone()
        image_c = image_c.squeeze(0)
        image_c = image_c.permute(1, 2, 0)
        # 将 tensor 转换为 PIL 图像
        image_g_pil = Image.fromarray((image_g.detach().numpy() * 255).astype('uint8'))
        image_c_pil = Image.fromarray((image_c.detach().numpy() * 255).astype('uint8'))
        # 拼接图像
        concatenated_image = Image.new('RGB', (image_g_pil.width + image_c_pil.width, image_g_pil.height))
        concatenated_image.paste(image_c_pil, (0, 0))
        concatenated_image.paste(image_g_pil, (image_c_pil.width, 0))
        output_path = 'out/cpu/'
        output_filename = f'concatenated_image_{i}.jpg'
        output_filepath = output_path + output_filename
        concatenated_image.save(output_filepath)
    print("TEST RESULT PASS!\n")
